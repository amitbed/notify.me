package com.notifyapp.amitbed.notifyme;

import android.app.Fragment;

/**
 * Created by amitbed on 04/11/2017.
 */

public class ContactsFragment extends Fragment {
}
